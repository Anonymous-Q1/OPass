import tvm
from tvm import relay, topi
from tvm.relay import transform, analysis
from tvm.relay.testing.temp_op_attr import TempOpAttr
from tvm.relay.testing import run_infer_type
import numpy as np
import tvm.testing
from tvm.relay import testing

x = relay.var("x", shape=(1, 1, 1, 1))
y = relay.image.resize2d(x, (2, 4))
z = relay.mean(y, axis=0)
a = relay.image.resize1d(z, (1,))
func = relay.Function((x,), a)
mod = tvm.IRModule.from_expr(func)

with open('./code.txt', 'w') as f:
    f.write(mod.astext())
