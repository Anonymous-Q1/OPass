import tvm
from tvm import relay
import tvm.relay.transform as transform
from tvm.relay.op.annotation import compiler_begin, compiler_end
from tvm.relay.testing import run_opt_pass

def before():
        data = relay.var("data", shape=(1, 32))
        add0 = relay.add(data, data)
        sub0 = relay.subtract(add0, data)
        eq = relay.equal(relay.sum(add0), relay.sum(sub0))

        true_branch = relay.sigmoid(add0)
        false_branch = relay.sigmoid(sub0)
        ife = relay.If(eq, true_branch, false_branch)
        erf = relay.erf(ife)
        out = relay.add(add0, erf)
        func = relay.Function([data], out)
        mod = tvm.IRModule.from_expr(func)

        return mod
    
mod = before()


with open('./code.txt', 'w') as f:
    f.write(mod.astext())
