import tvm
import tvm.testing
from tvm.relay import Function, transform
from tvm.relay.testing import inception_v3
import pytest
import sys

def before():
    mod = tvm.IRModule()

    shape = (10, 10)
    dtype = "float32"
    t = relay.TensorType(shape, dtype)

    x = relay.var("x", t)
    y = relay.Function([x], x + relay.ones_like(x))

    mod["main"] = y
    return mod
    
mod = before()

with open('./code.txt', 'w') as f:
    f.write(mod.astext())
