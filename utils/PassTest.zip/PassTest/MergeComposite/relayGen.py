import pytest
import tvm
from tvm import relay, tir
from tvm.relay.dataflow_pattern import TuplePattern, TupleGetItemPattern, is_op, wildcard
from tvm.relay.testing import run_opt_pass

def before():
        a = relay.var("a", shape=(10, 10))
        b = relay.var("b", shape=(10, 10))
        c = relay.reshape(a, [20, 5])
        d = relay.reshape(b, [20, 5])
        r = relay.einsum([c, d], "...ab,...cb->...ac")
        return relay.Function([a, b], r)


f = before()
mod = tvm.IRModule.from_expr(f)


with open('./code.txt', 'w') as f:
    f.write(mod.astext())
