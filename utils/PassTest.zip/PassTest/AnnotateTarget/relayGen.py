import os
import sys
import numpy as np
import pytest

import tvm
import tvm.relay.testing
import tvm.relay.transform as transform
from tvm import relay
from tvm import runtime
from tvm.contrib import utils

func = relay.Function([], relay.Tuple([]))
mod = tvm.IRModule.from_expr(func)



with open('./code.txt', 'w') as f:
    f.write(mod.astext())
